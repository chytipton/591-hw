export interface Profile {
    id: String;
    first_name: String;
    last_name: String;
    favorite_category: String;
  }